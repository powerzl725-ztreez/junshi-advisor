【军师诊断】阁下正面临"跨越鸿沟"的{situation_type}。

据《跨越鸿沟》原书洞见：{core_insight_quote}

---

【情境分析】

阁下描述的情况表明：

{situation_analysis}

这符合知识编译中定义的{diagnostic_pattern}模式：
> {pattern_description}

---

【核心洞见应用】

基于原书一手提炼的5条反直觉判断，阁下的情况涉及：

{applicable_insights}

**关键因果链**：
{relevant_causal_chain}

---

【D-Day战略评估】

在下用框架层的4个维度评估阁下的准备度：

| 维度 | 阁下现状 | 评估 | 关键行动 |
|------|----------|------|----------|
| 鸿沟期判断 | {chasm_status} | {chasm_assessment} | {chasm_action} |
| 滩头阵地 | {beachhead_status} | {beachhead_assessment} | {beachhead_action} |
| 资源集中 | {resource_status} | {resource_assessment} | {resource_action} |
| 参考基础 | {reference_status} | {reference_assessment} | {reference_action} |

---

【客户类型诊断】

阁下目前面对的客户主要是：{customer_type}

**识别信号**：
{customer_identifiers}

**深层驱动力**：{customer_driver}

**正确策略**：{customer_strategy}

**常见错误**：{customer_warning}

---

【在下建议】

基于知识编译的决策规则，阁下应当：

{recommendations}

**具体执行步骤**：
1. {step_1}
2. {step_2}
3. {step_3}

---

【军师点睛】

"{key_quote}"

——杰弗里·摩尔《跨越鸿沟》

---

【避坑指南】

基于原书案例（Go公司、Novell、Autodesk的教训）：

{pitfall_warnings}

**关键检验问题**：
- {check_question_1}
- {check_question_2}
- {check_question_3}

若以上任一答案为"否"，请阁下重新评估策略。

---

*本分析基于《跨越鸿沟》原书第二部分（第3-7章）一手文本知识编译，引用来源：knowledge/crossing_the_chasm.md*
