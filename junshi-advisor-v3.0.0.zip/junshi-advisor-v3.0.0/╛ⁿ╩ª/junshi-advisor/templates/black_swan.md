【军师诊断】阁下正面对一只"黑天鹅"。塔勒布在《黑天鹅》中揭示：极端事件具有三个特征——意外性、极端影响、事后可解释性。我们无法预测黑天鹅，但可以提前构建应对能力。

基于知识编译分析：
- 领域性质：{domain_nature}（极端斯坦/平均斯坦）
- 可预测性：{predictability}
- 影响评估：{impact_level}（局部可控/全面冲击/生存威胁）

【脆弱性评估】
- 冗余度：{redundancy_level}
  - 财务缓冲：{financial_buffer}
  - 运营备份：{operational_backup}
  - 人力储备：{human_backup}
- 杠杆度：{leverage_level}
  - 财务杠杆：{financial_leverage}
  - 运营杠杆：{operational_leverage}
- 恢复力：{resilience_level}
  - 流动性：{liquidity_status}
  - 业务多样性：{business_diversity}

【核心评估】
1. **事件性质分析**：{event_analysis}
   - 是否符合黑天鹅三特征？{black_swan_traits}
   - 是否处于极端斯坦领域？{extremistan_check}

2. **认知偏差检查**：{cognitive_bias_check}
   - 证实谬误：是否只看见支持已有观点的证据？
   - 叙述谬误：是否在用故事解释随机事件？
   - 事后解释：是否在事后构建"本该如此"的叙事？

3. **脆弱性诊断**：{fragility_diagnosis}
   - 系统脆弱性：{system_fragility}
   - 关键风险点：{key_risk_points}

【在下建议】

**短期应对**：
- 若局部可控：阁下先隔离受影响区域，防止扩散，再逐步修复。重点关注：{immediate_actions}
- 若全面冲击：阁下此时不要试图恢复原状，而要思考"这个变化创造了什么新机会"。建议：{pivot_suggestions}
- 若生存威胁：阁下应立即启动"最小生存方案"——砍掉一切非必要支出，保住核心资产。紧急措施：{emergency_measures}

**中期调整**：
- 建立冗余：{redundancy_recommendations}
- 降低杠杆：{deleverage_recommendations}
- 增强恢复力：{resilience_recommendations}

**长期建设**：
- 采用杠铃策略：{barbell_strategy}
  - 90%极度安全：{safe_allocation}
  - 10%高风险高回报：{risky_allocation}
- 建立反脆弱性：{antifragility_building}

【军师点睛】
"黑天鹅不可预测，但你可以让自己不怕它。风会熄灭蜡烛，却能使火越烧越旺。"

【避坑指南】
1. **切勿事后归因**：阁下切勿在黑天鹅事件后急于"找原因"或"追责"。事后归因是人类的本能，但它既不能改变已发生的事，也会浪费宝贵的应对时间。先活下来，再复盘。

2. **警惕过度自信**：不要因为"过去都没问题"就放松警惕。在极端斯坦中，历史数据无法预测未来。

3. **避免中间地带**：最危险的是"看起来安全其实危险"的中间地带——既没有安全保障，又没有高回报潜力。

4. **预防价值被低估**：预防成功的人往往得不到认可，救火的人反而成为英雄。阁下要建立正确的激励机制。

5. **不要量化不可量化**：不要试图用钟形曲线和置信区间来"量化"黑天鹅风险。在极端斯坦中，这些工具是危险的幻觉。
