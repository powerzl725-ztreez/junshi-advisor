# 军师 (Junshi Advisor)

> 愿「军师.skill」助阁下决胜职场。

[![Qoder Skill](https://img.shields.io/badge/Qoder-Skill-blue)](https://qoder.com)
[![Version](https://img.shields.io/badge/version-2.0.0-green)](./config.yaml)
[![License](https://img.shields.io/badge/license-MIT-yellow)](./LICENSE)

军师是一个 [QoderWork](https://qoder.com) 智能体技能，将军事理论与管理智慧转化为可执行的职场决策建议。

## 核心特点

- **12大谋略模块**：涵盖军事经典与商业管理理论
- **模块化架构**：YAML 定义 + Markdown 模板，易于扩展
- **结构化输出**：诊断 → 评估 → 建议 → 点睛 → 避坑
- **沉浸式体验**：军师语气（在下/阁下），增强信任感与仪式感

## 谋略模块一览

### 军事理论模块（六大经典）

| 模块 | 来源 | 适用场景 |
|------|------|----------|
| **五事七计** | 《孙子兵法》 | 项目立项、可行性评估 |
| **先为不可胜** | 《孙子兵法》 | 风险评估、止损决策 |
| **重心打击** | 《战争论》 | 优先级排序、资源聚焦 |
| **阶段划分** | 《论持久战》 | 长期项目、坚持策略 |
| **非对称作战** | 《超限战》 | 以小博大、竞争策略 |
| **摩擦预留** | 《战争论》 | 排期规划、缓冲管理 |

### 商业/管理理论模块（六大扩展）

| 模块 | 来源 | 适用场景 |
|------|------|----------|
| **跨越鸿沟** | 《跨越鸿沟》 | 新产品上市、市场推广 |
| **创新者的窘境** | 《创新者的窘境》 | 内部创新、颠覆式创新 |
| **蓝海战略** | 《蓝海战略》 | 差异化竞争、价值创新 |
| **黑天鹅** | 《黑天鹅》 | 危机应对、极端事件 |
| **影响力** | 《影响力》 | 向上管理、跨部门沟通 |
| **反脆弱** | 《反脆弱》 | 职业风险配置、杠铃策略 |

## 安装使用

### 方式一：QoderWork 技能市场（待上架）

等待官方技能市场上架后，直接在 QoderWork 中搜索"军师"安装。

### 方式二：手动安装

1. 克隆本仓库到本地：
```bash
git clone https://github.com/yourname/junshi-advisor.git
```

2. 复制到 QoderWork skills 目录：
```bash
# macOS/Linux
cp -r junshi-advisor ~/.qoderwork/skills/

# Windows
xcopy /E /I junshi-advisor %USERPROFILE%\.qoderwork\skills\junshi-advisor
```

3. 重启 QoderWork 或开新对话，技能自动加载。

## 使用示例

### 示例 1：项目立项决策

**用户**：老板让我牵头一个新项目，要不要接？

**军师**（触发「五事七计」）：
> 【军师诊断】阁下正面临一次"庙算"问题...
> 
> 【五事评估】
> - 道（共识）：团队内部是否达成共识？上级是否支持？
> - 天（时机）：当前市场时机、政策环境如何？
> ...

### 示例 2：风险评估

**用户**：这个方案风险太大，我怕搞砸

**军师**（触发「先为不可胜」）：
> 【军师诊断】阁下正面临一个"风险评估"问题...
> 
> 【风险评估】
> - 最坏情况：{worst_loss}
> - 可承受性：{can_afford}
> ...

### 示例 3：向上管理

**用户**：如何推动领导层解决一线的问题？

**军师**（触发「影响力」+「跨越鸿沟」）：
> 【军师诊断】阁下正面临"跨越鸿沟"的经典困境...
> 
> 【六大影响力策略】
> 1. 互惠：先给领导一份竞品情报...
> 2. 社会认同：展示同行成功案例...
> ...

## 工程结构

```
junshi-advisor/
├── SKILL.md              # 主技能文件
├── config.yaml           # 全局配置
├── modules/              # 谋略模块（YAML，12个）
│   ├── five_affairs.yaml
│   ├── invincible_first.yaml
│   ├── crossing_the_chasm.yaml
│   └── ...
└── templates/            # 输出模板（Markdown，12个）
    ├── five_affairs.md
    ├── invincible_first.md
    ├── crossing_the_chasm.md
    └── ...
```

## 扩展新模块

无需修改 SKILL.md，只需两步：

1. 在 `modules/` 下新建 `your_module.yaml`：
```yaml
id: your_module
name: 你的模块名
version: "1.0.0"
source: "理论来源"
category: 分类
priority: 80
keywords:
  - 关键词1
  - 关键词2
input_prompts:
  - 追问问题1
  - 追问问题2
analysis_logic:
  dimensions:
    - 维度1
    - 维度2
output_template: your_module.md
```

2. 在 `templates/` 下新建 `your_module.md`，使用 `{variable}` 占位符。

重新加载即可生效。

## 贡献指南

欢迎提交 Issue 和 PR！

- 发现 bug？请提交 Issue，描述复现步骤
- 想新增模块？参考现有模块格式，提交 PR
- 有改进建议？欢迎讨论

## 许可证

[MIT License](./LICENSE)

## 致谢

- 军事理论：《孙子兵法》、克劳塞维茨《战争论》、毛泽东《论持久战》、乔良/王湘穗《超限战》
- 管理理论：杰弗里·摩尔、克莱顿·克里斯坦森、W·钱·金、纳西姆·塔勒布、罗伯特·西奥迪尼
- 平台：[QoderWork](https://qoder.com)

---

**愿「军师.skill」助阁下决胜职场。**
